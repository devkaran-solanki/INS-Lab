#include <stdio.h>
#include <ctype.h>

int main()
{
    char key[100];
    int isPlaced[26] = {0};
    char keyMatrix[5][5];

    printf("Enter key: ");
    fgets(key, sizeof(key), stdin);

    int row = 0, col = 0;

    for (int i = 0; key[i] != '\0'; i++)
    {
        if (isalpha(key[i]))
        {
            char ch = toupper(key[i]);

            if (ch == 'J')
                ch = 'I';

            if (!isPlaced[ch - 'A'])
            {
                keyMatrix[row][col] = ch;
                isPlaced[ch - 'A'] = 1;

                col++;
                if (col == 5)
                {
                    col = 0;
                    row++;
                }
            }
        }
    }

    for (char ch = 'A'; ch <= 'Z'; ch++)
    {
        if (ch == 'J') continue;

        if (!isPlaced[ch - 'A'])
        {
            keyMatrix[row][col] = ch;
            isPlaced[ch - 'A'] = 1;

            col++;
            if (col == 5)
            {
                col = 0;
                row++;
            }
        }
    }

    printf("\nPlayfair Key Matrix:\n");
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            printf("%c ", keyMatrix[i][j]);
        }
        printf("\n");
    }

    return 0;
}
