// #include <stdio.h>

// void main()
// {

//     char map[26] = "qaztwsecrfxvgbnyhpudljmoik";

//     char str[100];
//     printf("Enter a string: ");
//     fgets(str, sizeof(str), stdin);

//     char key[100];
//     printf("Enter key (press Enter to omit): ");
//     fgets(key, sizeof(key), stdin);

// }

#include <stdio.h>
#include <string.h>

void main()
{
    char map[26] = "qaztwsecrfxvgbnyhpudljmoik";
    char customMap[26];
    char str[100];
    char key[100];

    int used[26] = {0}; // track letters used in the custom map
    int index = 0;

    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);
    // remove newline if present
    str[strcspn(str, "\n")] = 0;

    printf("Enter key (press Enter to omit): ");
    fgets(key, sizeof(key), stdin);
    key[strcspn(key, "\n")] = 0;

    // Step 1: Add key letters first
    for (int i = 0; i < strlen(key); i++)
    {
        char c = key[i];
        // convert uppercase to lowercase manually
        if (c >= 'A' && c <= 'Z')
            c = c - 'A' + 'a';
        if (c >= 'a' && c <= 'z')
        {
            int pos = c - 'a';
            if (!used[pos])
            {
                customMap[index++] = c;
                used[pos] = 1;
            }
        }
    }

    // Step 2: Fill remaining letters from original map
    for (int i = 0; i < 26; i++)
    {
        char c = map[i];
        if (c >= 'A' && c <= 'Z')
            c = c - 'A' + 'a';
        int pos = c - 'a';
        if (!used[pos])
        {
            customMap[index++] = c;
            used[pos] = 1;
        }
    }

    // Print the custom map
    printf("Custom key map: ");
    for (int i = 0; i < 26; i++)
        printf("%c", customMap[i]);
    printf("\n");

    // Example encryption of the input string
    printf("Encrypted string: ");
    for (int i = 0; str[i] != 0; i++)
    {
        char c = str[i];
        if (c >= 'A' && c <= 'Z')
            c = c - 'A' + 'a';
        if (c >= 'a' && c <= 'z')
        {
            printf("%c", customMap[c - 'a']);
        }
        else
        {
            printf("%c", c); // non-letters unchanged
        }
    }
    printf("\n");
}
