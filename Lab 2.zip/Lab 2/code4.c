// 4. Write a C program to test whether a number is prime or composite.

#include <stdio.h>

void main()
{
    int num;
    printf("\nEnter a number: ");
    scanf("%d", &num);

    if ((num == 0) || (num == 1))
        printf("\n%d is neither Prime nor Composite.\n\n", num);
    else
    {
        int divisors = 0;

        for (int i = 1; (i <= num / 2) && (divisors <= 1); i++)
            if (num % i == 0)
                divisors++;

        if (divisors == 1)
            printf("\n%d is Prime.\n\n", num);
        else
            printf("\n%d is Composite and has %d divisors.\n\n", num, (divisors + 1));
    }
}