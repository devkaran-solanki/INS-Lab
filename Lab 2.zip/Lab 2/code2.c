// 2. Implement string functions like strlen, strcat, and strcmp.

#include <stdio.h>
#include <string.h>

void main()
{

    char string1[] = "Hello ";
    char string2[] = "World!";

    printf("\nLength of String 1: %d", strlen(string1));
    printf("\nLength of String 2: %d", strlen(string2));

    printf("\n\nConcatenation of String 1 and String 2: %s", strcat(string1, string2));

    printf("\n\nComparison of String 1 and String 2: ");

    int comparison = strcmp(string1, string2);

    if (comparison == 0)
        printf("String 1 and String 2 are same.\n\n");
    else if (comparison < 0)
        printf("String 1 is lexicographically smaller than String 2.\n\n");
    else
        printf("String 1 is lexicographically greater than String 2.\n\n");
}