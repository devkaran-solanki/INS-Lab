// 3. Implement a program to read and write a text file.

#include <stdio.h>

void main()
{
    FILE *fp;
    int action;
    printf("\n0. Read");
    printf("\n1. Write");
    printf("\nSelect an action: ");
    scanf("%d", &action);

    while (action != 0 || action != 1)
    {
        printf("\nInvalid selection, please select a valid action: ");
        scanf("%d", &action);
    }

    if (action == 0)
    {
        fp = fopen("demo.txt", "r");
        char ch;

        while ((ch = fgetc(fp)) != EOF)
            putchar(ch);
    }
    else
    {
        fp = fopen("demo.txt", "w");

        char str[100];
        printf("\nEnter a string:   ");
        gets(str);

        fprintf(fp, str);
    }
}