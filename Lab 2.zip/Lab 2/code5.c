// 5. Write a C program to generate prime numbers in a given range.

#include <stdio.h>

void main()
{
    int start, end;
    printf("\nEnter starting number of range: ");
    scanf("%d", &start);
    printf("Enter ending number of range: ");
    scanf("%d", &end);

    printf("\nPrime Number from %d to %d are:\n", start, end);

    for (int num = start; num <= end; num++)
    {
        int divisors = 0;

        for (int i = 1; (i <= num / 2) && (divisors <= 1); i++)
            if (num % i == 0)
                divisors++;

        if (divisors == 1)
            printf("%d ", num);
    }
    printf("\n\n");
}