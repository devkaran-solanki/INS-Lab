// 1. Write a program to reverse a string using pointers.

#include <stdio.h>
#include <string.h>

void reverseString(char *str)
{
    char *start = str;
    char *end = str + strlen(str) - 1;
    char temp;

    while (start < end)
    {
        temp = *start;
        *start = *end;
        *end = temp;

        start++;
        end--;
    }
}

void main()
{
    char str[100];

    printf("\nEnter a string:   ");
    gets(str);

    reverseString(str);

    printf("\nReversed string:  %s\n\n", str);
}
