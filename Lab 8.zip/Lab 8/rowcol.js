let text = "Devkaran Solanki";
console.log("Plaintext:", text);
text = text.replace(/\s+/g, '').toUpperCase();

let key = "2341";
let colCount = key.length;

while (text.length % colCount != 0) {
   text += 'Z'; 
}

let arr = [];
let index = 0;
let rowCount = text.length/colCount;

for (let i = 0; i < rowCount; i++) {
    let row = [];
    for (let j = 0; j < colCount; j++) {
        row.push(text[index]);
        index++;
    }
    arr.push(row);
}

let cipherArr = [];

for (let num = 1; num <= colCount; num++) {
    let currentCol = key.indexOf(num.toString());
    let colData = "";

    for (let r = 0; r < rowCount; r++) {
        colData += arr[r][currentCol];
    }

    cipherArr.push(colData);
}

let cipher = cipherArr.join('');

console.log("Ciphertext:", cipher);