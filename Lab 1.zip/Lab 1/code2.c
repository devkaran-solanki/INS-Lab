// 2. Write a C program to perform bitwise AND, OR, XOR, and NOT operations on integers.

#include <stdio.h>

void main()
{

    int a, b;
    printf("\nEnter value of variable 'a': ");
    scanf("%d", &a);
    printf("Enter value of variable 'b': ");
    scanf("%d", &b);

    printf("\na & b = %d", a & b);
    printf("\na | b = %d", a | b);
    printf("\na ^ b = %d", a ^ b);
    printf("\na ~ a = %d\n\n", ~a);
}