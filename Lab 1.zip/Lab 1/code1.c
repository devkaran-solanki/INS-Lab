// 1. Write a C program to count the number of 1’s and 0’s in the binary representation of a number.

#include <stdio.h>

void main()
{

    int num;
    printf("\nEnter a number: ");
    scanf("%d", &num);

    int numCopy = num;

    int binRev = 0;
    int binary = 0;

    int firstZerosCount = 0;

    while (numCopy % 2 == 0)
    {
        firstZerosCount++;
        numCopy = numCopy / 2;
    }

    numCopy = num;

    while (numCopy != 0)
    {
        if (numCopy % 2 == 0)
            binRev = binRev * 10;
        else
            binRev = binRev * 10 + 1;

        numCopy = numCopy / 2;
    }

    while (binRev != 0)
    {
        binary = binary * 10 + (binRev % 10);
        binRev = binRev / 10;
    }

    for (int i = 0; i < firstZerosCount; i++)
        binary = binary * 10;

    int binCopy = binary;
    int numZero = 0, numOne = 0;

    while (binCopy != 0)
    {
        if (binCopy % 10 == 0)
            numZero++;
        else
            numOne++;
        binCopy = binCopy / 10;
    }

    printf("\nBinary:       %d\n", binary);
    printf("No. of Zero:  %d\n", numZero);
    printf("No. of One:   %d\n\n", numOne);
}