// 4. Write a C program to implement left and right circular bit rotations.

#include <stdio.h>

void main()
{
    int n, d;

    printf("\nEnter a number: ");
    scanf("%d", &n);
    printf("Enter number of bits to shift: ");
    scanf("%d", &d);

    printf("\nLeft shift by %d:   %d\n", d, n << d);
    printf("Right shift by %d:  %d\n\n", d, n >> d);
}