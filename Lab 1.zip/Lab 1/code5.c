// 5. Write a C program to swap two variables without using a third variable (using XOR).

#include <stdio.h>

void main()
{
    int a, b;

    printf("Enter first number: ");
    scanf("%d", &a);
    printf("Enter second number: ");
    scanf("%d", &b);

    printf("\nBefore swapping: a = %d, b = %d\n", a, b);

    a = a ^ b;
    b = a ^ b;
    a = a ^ b;

    printf("After swapping:  a = %d, b = %d\n", a, b);
}