// 3. Write a C program that takes a string and performs bitwise AND and XOR operations with a constant value (e.g., 127). (Simulates simple encryption idea)

#include <stdio.h>
#include <string.h>

void main()
{
    printf("\nEnter a string: ");

    char str[100];
    gets(str);

    int key = 127;

    char AND[100];
    char XOR[100];

    int len = strlen(str);

    printf("\nASCII:  ");
    for (int i = 0; i < len; i++)
    {
        printf("%d ", str[i]);
        AND[i] = str[i] & key;
        XOR[i] = str[i] ^ key;
    }

    printf("\n\nAND:    ");
    for (int i = 0; i < len; i++)
        printf("%d ", AND[i]);

    printf("\nXOR:    ");
    for (int i = 0; i < len; i++)
        printf("%d ", XOR[i]);

    printf("\n\n");
}