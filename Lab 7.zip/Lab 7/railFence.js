// Implementation of Rail Fence Technique using Javascript

let text = "computer";
let key = 4, row = 4;
let cipher = "";

for (let i = 0; i < row; i++) {
    for (let j = i; j < text.length; j += (2 * (key - 1))) {
        cipher += text[j];
    }
    key--;
    if(key == 1)
        key = 2;
    cipher += " ";
}

console.log(cipher);