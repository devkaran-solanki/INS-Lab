// Implementation of Rail Fence Technique using Javascript

function railFenceEncrypt(text, key) {
    if (key <= 1) return text;

    const rails = Array.from({ length: key }, () => "");

    let row = 0;
    let dir = 1;

    for (const ch of text) {
        rails[row] += ch;

        if (row === 0) dir = 1;
        else if (row === key - 1) dir = -1;

        row += dir;
    }

    return rails.join(" ");
}

let text = "subscribe channel study table";
console.log(railFenceEncrypt(text, 3));