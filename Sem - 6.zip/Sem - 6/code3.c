//3. Write a C program that takes a string and performs bitwise AND and XOR operations with a constant value (e.g., 127). (Simulates simple encryption idea)

#include<stdio.h>
#include<string.h>

void main() {

    printf("Enter a string: ");
    char str[] = "";
    gets(str);

    int key = 127;
    char AND[] = "";
    char XOR[] = "";

    for (int i = 0; i < strlen(str); i++) {
        AND[i] = str[i] & key;
        XOR[i] = str[i] ^ key;
    }

    printf("\nAND: %d", AND);
    printf("\nXOR: %d\n\n", XOR);

}